import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getLivros, searchLivros } from '../utils/supabase';

const Livros = () => {
  const [livros, setLivros] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('todos');

  useEffect(() => {
    loadLivros();
  }, []);

  const loadLivros = async () => {
    try {
      const { data, error } = await getLivros();
      if (error) throw error;
      setLivros(data || []);
    } catch (error) {
      console.error('Erro ao carregar livros:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async (term) => {
    setSearchTerm(term);
    if (term.trim() === '') {
      loadLivros();
      return;
    }

    try {
      setLoading(true);
      const { data, error } = await searchLivros(term);
      if (error) throw error;
      setLivros(data || []);
    } catch (error) {
      console.error('Erro na pesquisa:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredLivros = livros.filter(livro => {
    if (filter === 'disponiveis') return true; // Simplificado para demo
    if (filter === 'requisitados') return false; // Simplificado para demo
    return true;
  });

  useEffect(() => {
    // Animação dos cards
    anime({
      targets: '.livro-card',
      scale: [0.9, 1],
      opacity: [0, 1],
      delay: anime.stagger(100),
      duration: 500,
      easing: 'easeOutQuart'
    });
  }, [filteredLivros]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600"></div>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <div>
          <h1 className="serif-font text-3xl font-bold text-gray-900 mb-2">Gestão de Livros</h1>
          <p className="text-gray-600">Gerir o acervo da biblioteca escolar</p>
        </div>
        <Link
          to="/livros/novo"
          className="mt-4 sm:mt-0 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg text-white crimson-gradient hover:shadow-lg transition-all duration-200"
        >
          <span className="mr-2">➕</span>
          Adicionar Livro
        </Link>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <input
                type="text"
                placeholder="Pesquisar por título, autor ou ISBN..."
                value={searchTerm}
                onChange={(e) => handleSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              />
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <svg className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setFilter('todos')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                filter === 'todos' ? 'bg-red-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Todos
            </button>
            <button
              onClick={() => setFilter('disponiveis')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                filter === 'disponiveis' ? 'bg-red-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Disponíveis
            </button>
            <button
              onClick={() => setFilter('requisitados')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                filter === 'requisitados' ? 'bg-red-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Requisitados
            </button>
          </div>
        </div>
      </div>

      {/* Books Grid */}
      {filteredLivros.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-2xl">📚</span>
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhum livro encontrado</h3>
          <p className="text-gray-600 mb-4">
            {searchTerm ? 'Tente ajustar a sua pesquisa' : 'Comece por adicionar o primeiro livro'}
          </p>
          {!searchTerm && (
            <Link
              to="/livros/novo"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg text-white crimson-gradient hover:shadow-lg transition-all duration-200"
            >
              <span className="mr-2">➕</span>
              Adicionar Primeiro Livro
            </Link>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredLivros.map((livro) => (
            <div key={livro.li_cod} className="livro-card bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden card-hover">
              {/* Book Cover Placeholder */}
              <div className="h-48 bg-gradient-to-br from-red-100 to-red-200 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-4xl mb-2">📖</div>
                  <p className="text-sm text-red-700 font-medium">Capa do Livro</p>
                </div>
              </div>

              <div className="p-4">
                <h3 className="font-semibold text-gray-900 mb-1 line-clamp-2">
                  {livro.li_titulo}
                </h3>
                <p className="text-sm text-gray-600 mb-2">
                  por {livro.autor?.au_nome || 'Autor desconhecido'}
                </p>
                <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                  <span>{livro.li_ano || 'Ano desconhecido'}</span>
                  <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full">
                    Disponível
                  </span>
                </div>
                <div className="flex gap-2">
                  <Link
                    to={`/livros/${livro.li_cod}`}
                    className="flex-1 px-3 py-2 text-sm font-medium text-red-600 border border-red-200 rounded-lg hover:bg-red-50 transition-colors text-center"
                  >
                    Ver Detalhes
                  </Link>
                  <button className="px-3 py-2 text-sm font-medium text-white bg-red-600 rounded-lg hover:bg-red-700 transition-colors">
                    Editar
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Livros;