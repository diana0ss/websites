import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getLivros, getUtentes, getRequisicoes } from '../utils/supabase';

const Dashboard = () => {
  const [stats, setStats] = useState({
    totalLivros: 0,
    totalUtentes: 0,
    requisicoesAtivas: 0,
    livrosDisponiveis: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [livrosData, utentesData, requisicoesData] = await Promise.all([
        getLivros(),
        getUtentes(),
        getRequisicoes()
      ]);

      const totalLivros = livrosData.data?.length || 0;
      const totalUtentes = utentesData.data?.length || 0;
      const requisicoesAtivas = requisicoesData.data?.filter(r => !r.re_data_devolucao).length || 0;
      
      setStats({
        totalLivros,
        totalUtentes,
        requisicoesAtivas,
        livrosDisponiveis: Math.max(0, totalLivros - requisicoesAtivas)
      });
    } catch (error) {
      console.error('Erro ao carregar dados do dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    {
      title: 'Total de Livros',
      value: stats.totalLivros,
      icon: '📚',
      color: 'bg-red-500',
      link: '/livros'
    },
    {
      title: 'Utentes Registados',
      value: stats.totalUtentes,
      icon: '👥',
      color: 'bg-red-400',
      link: '/utentes'
    },
    {
      title: 'Requisições Ativas',
      value: stats.requisicoesAtivas,
      icon: '📖',
      color: 'bg-red-300',
      link: '/requisicoes'
    },
    {
      title: 'Livros Disponíveis',
      value: stats.livrosDisponiveis,
      icon: '📖',
      color: 'bg-red-200',
      link: '/livros'
    }
  ];

  useEffect(() => {
    // Animação dos cards
    anime({
      targets: '.stat-card',
      scale: [0.8, 1],
      opacity: [0, 1],
      delay: anime.stagger(150),
      duration: 600,
      easing: 'easeOutBack'
    });
  }, [loading]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600"></div>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="mb-8">
        <h1 className="serif-font text-4xl font-bold text-gray-900 mb-2">
          Bem-vindo à Biblioteca Escolar
        </h1>
        <p className="text-gray-600 text-lg">
          Gestão completa do acervo e requisições
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statCards.map((stat, index) => (
          <Link
            key={index}
            to={stat.link}
            className="stat-card bg-white rounded-xl shadow-sm border border-gray-200 p-6 card-hover"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">{stat.title}</p>
                <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
              </div>
              <div className={`w-12 h-12 ${stat.color} rounded-lg flex items-center justify-center text-white text-xl`}>
                {stat.icon}
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
        <h2 className="serif-font text-2xl font-bold text-gray-900 mb-4">Ações Rápidas</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Link
            to="/livros/novo"
            className="flex items-center space-x-3 p-4 border-2 border-dashed border-red-300 rounded-lg hover:border-red-500 hover:bg-red-50 transition-colors"
          >
            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
              <span className="text-red-600 text-xl">➕</span>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Adicionar Livro</h3>
              <p className="text-sm text-gray-600">Registar novo livro no sistema</p>
            </div>
          </Link>

          <Link
            to="/requisicoes/nova"
            className="flex items-center space-x-3 p-4 border-2 border-dashed border-red-300 rounded-lg hover:border-red-500 hover:bg-red-50 transition-colors"
          >
            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
              <span className="text-red-600 text-xl">📤</span>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Nova Requisição</h3>
              <p className="text-sm text-gray-600">Emprestar livro a utente</p>
            </div>
          </Link>

          <Link
            to="/utentes/novo"
            className="flex items-center space-x-3 p-4 border-2 border-dashed border-red-300 rounded-lg hover:border-red-500 hover:bg-red-50 transition-colors"
          >
            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
              <span className="text-red-600 text-xl">👤</span>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Registar Utente</h3>
              <p className="text-sm text-gray-600">Adicionar novo utilizador</p>
            </div>
          </Link>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="serif-font text-2xl font-bold text-gray-900 mb-4">Atividade Recente</h2>
        <div className="space-y-4">
          <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
            <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
              <span className="text-red-600">📚</span>
            </div>
            <div className="flex-1">
              <p className="font-medium text-gray-900">Sistema iniciado com sucesso</p>
              <p className="text-sm text-gray-600">Todos os módulos estão funcionando corretamente</p>
            </div>
            <span className="text-sm text-gray-500">Agora</span>
          </div>

          <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
            <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
              <span className="text-red-600">✅</span>
            </div>
            <div className="flex-1">
              <p className="font-medium text-gray-900">Base de dados conectada</p>
              <p className="text-sm text-gray-600">Conexão com Supabase estabelecida</p>
            </div>
            <span className="text-sm text-gray-500">Agora</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;