import { createClient } from '@supabase/supabase-js';

// Configuração do Supabase - substituir com os valores reais do projeto
const supabaseUrl = process.env.REACT_APP_SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseAnonKey = process.env.REACT_APP_SUPABASE_ANON_KEY || 'your-anon-key';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Funções auxiliares para operações comuns
export const getLivros = async () => {
  const { data, error } = await supabase
    .from('livro')
    .select(`*, autor(*), editora(*), genero(*)`);
  return { data, error };
};

export const getAutores = async () => {
  const { data, error } = await supabase
    .from('autor')
    .select('*');
  return { data, error };
};

export const getEditoras = async () => {
  const { data, error } = await supabase
    .from('editora')
    .select(`*, codigo_postal(*)`);
  return { data, error };
};

export const getUtentes = async () => {
  const { data, error } = await supabase
    .from('utente')
    .select(`*, codigo_postal(*)`);
  return { data, error };
};

export const getRequisicoes = async () => {
  const { data, error } = await supabase
    .from('requisicao')
    .select(`*, utente(*), livro_exemplar(*, livro(*))`);
  return { data, error };
};

export const searchLivros = async (termo) => {
  const { data, error } = await supabase
    .from('livro')
    .select(`*, autor(*), editora(*)`)
    .or(`li_titulo.ilike.%${termo}%,autor.au_nome.ilike.%${termo}%`);
  return { data, error };
};