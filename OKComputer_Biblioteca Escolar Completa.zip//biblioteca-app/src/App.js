import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Livros from './pages/Livros';
import Autores from './pages/Autores';
import Editoras from './pages/Editoras';
import Utentes from './pages/Utentes';
import Requisicoes from './pages/Requisicoes';

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/livros" element={<Livros />} />
        <Route path="/autores" element={<Autores />} />
        <Route path="/editoras" element={<Editoras />} />
        <Route path="/utentes" element={<Utentes />} />
        <Route path="/requisicoes" element={<Requisicoes />} />
      </Routes>
    </Layout>
  );
}

export default App;