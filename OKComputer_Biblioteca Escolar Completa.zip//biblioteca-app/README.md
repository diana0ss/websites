# Biblioteca Escolar - Sistema de Gestão

Uma aplicação web completa para gestão de biblioteca escolar desenvolvida em React com integração Supabase.

## 🎨 Design

- **Cores**: Esquema em branco e vermelho (crimson red #DC143C)
- **Tipografia**: Playfair Display para títulos (serifada), Inter para conteúdo
- **Estilo**: Design moderno e limpo com elementos académicos

## ✨ Funcionalidades

### Módulos Principais
- **Dashboard**: Visão geral com estatísticas e ações rápidas
- **Gestão de Livros**: CRUD completo para livros e exemplares
- **Gestão de Autores**: Cadastro e listagem de autores
- **Gestão de Editoras**: Cadastro e listagem de editoras
- **Gestão de Utentes**: Registo de utilizadores da biblioteca
- **Requisições**: Sistema de empréstimo e devolução de livros

### Características
- ✅ Interface responsiva e intuitiva
- ✅ Pesquisa avançada em todas as secções
- ✅ Filtros por estado (disponível/requisitado)
- ✅ Animações suaves com Anime.js
- ✅ Design consistente com cores institucionais
- ✅ Integração completa com Supabase

## 🛠️ Tecnologias Utilizadas

- **React 18**: Framework principal
- **React Router DOM**: Navegação entre páginas
- **Supabase**: Backend e base de dados
- **Anime.js**: Animações e efeitos visuais
- **Tailwind CSS**: Estilização e design responsivo
- **Google Fonts**: Tipografia (Playfair Display + Inter)

## 📦 Instalação

### Pré-requisitos
- Node.js 16 ou superior
- npm ou yarn
- Conta Supabase configurada

### Passos de Instalação

1. **Clonar o projeto**
   ```bash
   git clone [url-do-repositorio]
   cd biblioteca-escolar
   ```

2. **Instalar dependências**
   ```bash
   npm install
   ```

3. **Configurar Supabase**
   Criar arquivo `.env` na raiz do projeto:
   ```env
   REACT_APP_SUPABASE_URL=https://your-project.supabase.co
   REACT_APP_SUPABASE_ANON_KEY=your-anon-key
   ```

4. **Executar a aplicação**
   ```bash
   npm start
   ```

A aplicação estará disponível em `http://localhost:3000`

## 🗄️ Estrutura da Base de Dados

### Tabelas Principais
- `autor`: Informações dos autores
- `editora`: Informações das editoras
- `livro`: Catálogo de livros
- `livro_exemplar`: Exemplares individuais
- `utente`: Utilizadores da biblioteca
- `requisicao`: Registo de empréstimos
- `codigo_postal`: Códigos postais
- `genero`: Géneros literários

## 🚀 Deploy

### Deploy em Produção
```bash
npm run build
```

Os ficheiros otimizados estarão na pasta `build/`

### Deploy com Vercel/Netlify
1. Fazer push para repositório Git
2. Conectar à plataforma de deploy
3. Configurar variáveis de ambiente
4. Deploy automático

## 📱 Navegação

- **/** - Dashboard principal
- **/livros** - Gestão de livros
- **/autores** - Gestão de autores
- **/editoras** - Gestão de editoras
- **/utentes** - Gestão de utentes
- **/requisicoes** - Gestão de requisições

## 🔧 Desenvolvimento

### Estrutura de Ficheiros
```
src/
├── components/
│   └── Layout.js          # Layout principal com sidebar
├── pages/
│   ├── Dashboard.js       # Página inicial
│   ├── Livros.js         # Gestão de livros
│   ├── Autores.js        # Gestão de autores
│   ├── Editoras.js       # Gestão de editoras
│   ├── Utentes.js        # Gestão de utentes
│   └── Requisicoes.js    # Gestão de requisições
├── utils/
│   └── supabase.js       # Configuração e funções Supabase
└── App.js               # Componente principal
```

### Adicionar Novas Funcionalidades
1. Criar novo componente em `src/pages/`
2. Adicionar rota em `App.js`
3. Implementar integração com Supabase
4. Adicionar link no menu lateral

## 🎨 Personalização

### Cores
Editar as variáveis CSS em `public/index.html`:
```css
:root {
    --crimson-red: #DC143C;
    --light-crimson: #FF6B7A;
    --dark-crimson: #B91C3C;
    --off-white: #FEFEFE;
    --light-gray: #F8F9FA;
    --medium-gray: #6B7280;
}
```

### Animações
Modificar parâmetros em cada componente:
```javascript
anime({
  targets: '.element',
  scale: [0.8, 1],
  opacity: [0, 1],
  duration: 600,
  easing: 'easeOutQuart'
});
```

## 📄 Licença

Este projeto foi desenvolvido para fins educacionais como exercício de gestão de biblioteca escolar.

## 🤝 Contribuições

Contribuições são bem-vindas! Por favor:
1. Faça fork do projeto
2. Crie uma branch para sua feature
3. Commit suas alterações
4. Push para a branch
5. Abra um Pull Request

## 📞 Suporte

Para questões ou suporte, consulte a documentação ou abra uma issue no repositório.

---

**Nota**: Esta aplicação faz parte de um exercício académico e deve ser adaptada para uso em produção conforme necessário.